/*
   Copyright (C) 2023 Intel Corporation.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, see <http://www.gnu.org/licenses/>.
*/

#pragma once
#include <spice/macros.h>

#define INTEL_VENDOR_ID 0x8086
#define AMD_VENDOR_ID 0x1002

typedef enum {
    VENDOR_GPU_UNKNOWN,
    VENDOR_GPU_DETECTED,
    VENDOR_GPU_NOTDETECTED,
} GpuVendor;

SPICE_BEGIN_DECLS

GpuVendor spice_udev_detect_gpu(int gpu_vendor);

SPICE_END_DECLS
